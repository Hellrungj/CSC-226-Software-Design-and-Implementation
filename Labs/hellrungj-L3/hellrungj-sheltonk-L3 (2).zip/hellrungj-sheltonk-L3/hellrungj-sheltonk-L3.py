#-------- -----------------------------------------------------------------------
# Name:        John Hellrung & Kenan Shelton
# UserName:    hellrungj & sheltonk
# Purpose:
#
#
#
# Created:     28/03/2014
# Copyright:   (c) hellrungj 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import string

file_name = raw_input("file name")
# look for file name "upc-input1.txt, upc-input2.txt"

def barcode_split (file_name):
    """ This function is for opening the file and put each line into a list as
    element"""
    barcodelines = []
    lines= open(file_name, "r")
    while True:
        theline = lines.readline ()
        theline = theline.replace ('\n','')
        barcodelines.append(theline)
        if len(theline) == 0:
            break
    return barcodelines

for i in barcode_split(file_name):
    tepstring=i[1:11]
    print str(int(tepstring[0]))
    print str(int(tepstring[2]))
    print str(int(tepstring[4]))
    print str(int(tepstring[6]))
    print str(int(tepstring[8]))
print barcode_split (file_name) #Ask TA about the \n at the end.